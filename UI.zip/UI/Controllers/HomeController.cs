﻿using API;
using Common;
using System.Web.Mvc;
using UI.Models;

namespace UI.Controllers
{
	public class HomeController : Controller
	{
		public ActionResult Index()
		{
			//This would normally be a web reference to the API, but to keep it simple, new it up
			var service = new MessageService();

			var model = new MessageModel(); 
			model.Message = service.GetMessage(MessageType.HelloWorld);

			return View(model);
		}

		public ActionResult About()
		{
			ViewBag.Message = "Your application description page.";

			return View();
		}

		public ActionResult Contact()
		{
			ViewBag.Message = "Your contact page.";

			return View();
		}
	}
}