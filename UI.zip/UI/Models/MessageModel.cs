﻿namespace UI.Models
{
	public class MessageModel
	{
		public string Message { get; set; }
	}
}