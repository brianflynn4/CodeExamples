﻿using Common;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace DomainServices.Tests
{
	[TestClass()]
	public class MessageProcessorTests
	{
		IMessageProcessor service;

		[TestInitialize]
		public void Initialize()
		{
			//Here's where you would - if needed - either use DI to bypass DAO/DB access or potentially setup some globally scoped MOQ objects needed
			service = new MessageProcessor(); 
		}

		[TestMethod()]
		[ExpectedException(typeof(NotImplementedException))]
		public void GetMessageTestNotImplemented()
		{
			service.GetMessage(MessageType.HelloIsItMeYourLookingFor); 
		}


		[TestMethod()]
		[ExpectedException(typeof(NotImplementedException))]
		public void GetMessageTestNotImplemented2()
		{
			service.GetMessage(MessageType.GoodbyeCruelWorld);
		}

		[TestMethod()]
		public void GetMessageTest()
		{
			var result = service.GetMessage(MessageType.HelloWorld);
			Assert.AreEqual("Hello World", result, true); 
		}
	}
}