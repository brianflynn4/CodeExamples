﻿using Common;

namespace DomainServices
{
	public interface IMessageProcessor
	{
		string GetMessage(MessageType type);

	}
}
