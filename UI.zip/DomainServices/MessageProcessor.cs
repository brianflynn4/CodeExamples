﻿using Common;
using DomainServices.MessageGeneration;

namespace DomainServices
{
	public class MessageProcessor : IMessageProcessor
	{
		public string GetMessage(MessageType type)
		{
			var messageGenerator = MessageFactory.GetGenerator(type);
			return messageGenerator.GenerateMessage(); 
		}

    }
}
