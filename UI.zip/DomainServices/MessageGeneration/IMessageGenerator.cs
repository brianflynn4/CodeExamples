﻿namespace DomainServices.MessageGeneration
{
	public interface IMessageGenerator
	{
		string GenerateMessage();
	}
}
