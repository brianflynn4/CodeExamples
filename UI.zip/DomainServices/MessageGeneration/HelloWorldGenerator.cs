﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainServices.MessageGeneration
{
	public class HelloWorldGenerator : IMessageGenerator
	{
		public string GenerateMessage()
		{
			//Here's where you would normally reach out to the DB using an ORM or through a DAO or repository<T> access layer
			return "Hello World"; 
		}
	}
}
