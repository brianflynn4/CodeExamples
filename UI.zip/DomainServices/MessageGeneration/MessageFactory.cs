﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainServices.MessageGeneration
{
	public static class MessageFactory
	{

		public static IMessageGenerator GetGenerator(MessageType type)
		{
			switch (type)
			{
				case MessageType.HelloWorld:
					return new HelloWorldGenerator();
				case MessageType.GoodbyeCruelWorld:
				case MessageType.HelloIsItMeYourLookingFor:
					throw new NotImplementedException();
				default:
					throw new NotSupportedException();
			}
		}


	}
}
