﻿namespace Common
{
	public enum MessageType
	{
		HelloWorld,
		GoodbyeCruelWorld,
		HelloIsItMeYourLookingFor
	}
}
