﻿using Common;
using System.ServiceModel;

namespace API
{

	[ServiceContract]
	public interface IMessageService
	{
		[OperationContract]
		string GetMessage(MessageType type);
	}

}
