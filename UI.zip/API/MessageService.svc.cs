﻿using Common;
using DomainServices;

namespace API
{

	public class MessageService : IMessageService
	{
		//Normally you use constructor based dependency injection to resolve this service, but to keep this simple, new it up.
		MessageProcessor service => new MessageProcessor(); 

		public string GetMessage(MessageType type)
		{
			//API should generally do nothing but handle any API related logic
			return service.GetMessage(type);
		}

	}
}
